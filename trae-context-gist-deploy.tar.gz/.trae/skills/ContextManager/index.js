/**
 * trae-context-gist Skill - TRAE CN 上下文管理技能
 * 自动整理对话上下文，生成结构化笔记并存储到 GitHub Gist
 */

const fs = require('fs');
const path = require('path');

// 加载环境变量
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8');
  envContent.split('\n').forEach(line => {
    const [key, value] = line.split('=');
    if (key && value) {
      process.env[key.trim()] = value.trim();
    }
  });
}

/**
 * 分析对话上下文
 * @param {string} conversationHistory - 对话历史
 * @returns {object} 分析结果
 */
function analyzeContext(conversationHistory) {
  const keyPoints = [];
  const tasks = [];
  const decisions = [];
  
  // 简单的关键词提取
  const lines = conversationHistory.split('\n');
  lines.forEach(line => {
    const trimmedLine = line.trim();
    
    // 提取任务
    if (trimmedLine.includes('任务') || trimmedLine.includes('todo') || 
        trimmedLine.includes('需要') || trimmedLine.includes('要') ||
        trimmedLine.includes('计划')) {
      tasks.push(trimmedLine);
    }
    
    // 提取关键点
    if (trimmedLine.includes('重要') || trimmedLine.includes('关键') || 
        trimmedLine.includes('注意') || trimmedLine.includes('记住')) {
      keyPoints.push(trimmedLine);
    }
    
    // 提取决策
    if (trimmedLine.includes('决定') || trimmedLine.includes('确定') || 
        trimmedLine.includes('选择') || trimmedLine.includes('采用')) {
      decisions.push(trimmedLine);
    }
  });
  
  // 生成摘要
  const summary = `对话包含 ${tasks.length} 个任务、${keyPoints.length} 个关键点和 ${decisions.length} 个决策`;
  
  return {
    summary,
    keyPoints,
    tasks,
    decisions,
    timestamp: new Date().toISOString(),
    conversationLength: lines.length,
    metadata: {
      version: '1.0.0',
      skill: 'trae-context-gist'
    }
  };
}

/**
 * 上传到 GitHub Gist
 * @param {object} content - 要上传的内容
 * @param {string} fileName - 文件名
 * @returns {Promise<object>} Gist 信息
 */
async function uploadToGist(content, fileName) {
  const token = process.env.GITHUB_TOKEN;
  
  if (!token) {
    throw new Error('GitHub Token 未配置，请检查 .env 文件');
  }
  
  // 使用 TRAE CN 内置的 fetch 或 node-fetch
  let fetchFn;
  if (typeof fetch !== 'undefined') {
    fetchFn = fetch;
  } else {
    try {
      const nodeFetch = require('node-fetch');
      fetchFn = nodeFetch;
    } catch (e) {
      throw new Error('无法找到 fetch 函数，请安装 node-fetch: npm install node-fetch');
    }
  }
  
  const response = await fetchFn('https://api.github.com/gists', {
    method: 'POST',
    headers: {
      'Authorization': `token ${token}`,
      'Content-Type': 'application/json',
      'User-Agent': 'TRAE-CN-ContextManager'
    },
    body: JSON.stringify({
      description: 'TRAE CN 上下文笔记',
      public: false,
      files: {
        [fileName]: {
          content: JSON.stringify(content, null, 2)
        }
      }
    })
  });
  
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`上传失败 (${response.status}): ${errorText}`);
  }
  
  return await response.json();
}

/**
 * 更新本地索引
 * @param {object} gistInfo - Gist 信息
 * @returns {object} 更新后的索引
 */
function updateLocalIndex(gistInfo) {
  const indexPath = path.join(__dirname, 'index.json');
  let index = {};
  
  if (fs.existsSync(indexPath)) {
    try {
      index = JSON.parse(fs.readFileSync(indexPath, 'utf8'));
    } catch (e) {
      index = {};
    }
  }
  
  const fileName = Object.keys(gistInfo.files)[0];
  
  index[gistInfo.id] = {
    fileName,
    createdAt: gistInfo.created_at,
    updatedAt: gistInfo.updated_at,
    url: gistInfo.html_url,
    description: gistInfo.description
  };
  
  fs.writeFileSync(indexPath, JSON.stringify(index, null, 2));
  return index;
}

/**
 * 搜索笔记
 * @param {string} keyword - 关键词
 * @returns {Array} 匹配的笔记
 */
function searchNotes(keyword) {
  const indexPath = path.join(__dirname, 'index.json');
  if (!fs.existsSync(indexPath)) {
    return [];
  }
  
  try {
    const index = JSON.parse(fs.readFileSync(indexPath, 'utf8'));
    const results = [];
    
    // 简单的关键词搜索
    Object.entries(index).forEach(([id, info]) => {
      if (info.fileName.includes(keyword) || 
          (info.description && info.description.includes(keyword))) {
        results.push({ id, ...info });
      }
    });
    
    return results;
  } catch (e) {
    return [];
  }
}

/**
 * 主技能函数 - 处理上下文
 * @param {string} conversationHistory - 对话历史
 * @returns {Promise<object>} 处理结果
 */
async function processContext(conversationHistory) {
  try {
    // 分析上下文
    const analysis = analyzeContext(conversationHistory);
    
    // 生成文件名
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const fileName = `context_${timestamp}.json`;
    
    // 上传到 Gist
    const gistInfo = await uploadToGist(analysis, fileName);
    
    // 更新本地索引
    updateLocalIndex(gistInfo);
    
    return {
      success: true,
      message: `上下文已整理并存储到云端`,
      gistUrl: gistInfo.html_url,
      gistId: gistInfo.id,
      analysis: {
        summary: analysis.summary,
        taskCount: analysis.tasks.length,
        keyPointCount: analysis.keyPoints.length,
        decisionCount: analysis.decisions.length
      }
    };
  } catch (error) {
    return {
      success: false,
      message: `处理失败：${error.message}`,
      error: error.message
    };
  }
}

/**
 * 获取所有笔记
 * @returns {Array} 笔记列表
 */
function getAllNotes() {
  const indexPath = path.join(__dirname, 'index.json');
  if (!fs.existsSync(indexPath)) {
    return [];
  }
  
  try {
    const index = JSON.parse(fs.readFileSync(indexPath, 'utf8'));
    return Object.entries(index).map(([id, info]) => ({ id, ...info }));
  } catch (e) {
    return [];
  }
}

// 导出技能
module.exports = {
  name: 'trae-context-gist',
  version: '1.0.0',
  description: '自动整理对话上下文并存储到 GitHub Gist',
  triggers: {
    manual: '整理上下文',
    schedule: 'hourly',
    autoOnEnd: true
  },
  execute: processContext,
  search: searchNotes,
  getAll: getAllNotes,
  analyze: analyzeContext
};
